import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

public class Translations {
    final public static int DEFAULT = 1, POINTER_OR_STATIC = 2, CONSTANT = 3, TEMP=4;
    private int counter = 0;
    private int ret_counter = 0;
    private static Translations inst = null;
//    String functionBeingDefined = null;
    String functionBeingDefined = "Sys.init";
    private HashMap<String, String> keywords;
    private HashMap<Integer, String> pops;
    private HashMap<Integer, String> pushs;
    private HashMap<String, String> Arithmetic;
    private HashMap<String, String> labelCommands;
    HashMap<String, Integer> function_param_num;
    private HashMap<Integer, String> function_num_to_labelName;
    private int depth = 0,prev_depth;


    public void reset_counter() { //todo: call in main after every file
        counter = 0;
    }

    private Translations() {
        //initialize hash's
        keywords = new HashMap<>( );
        pops = new HashMap<>( );
        labelCommands = new HashMap<>();
        pushs = new HashMap<>( );
        Arithmetic = new HashMap<>( );
        function_param_num = new HashMap<>( );
        reset_counter( );
        fillKeywords( );
        fillpop( );
        fillpush( );
        fillArithmatics( );
        fillLabelCommands();
    }

    public static Translations getTranslations() {
        if (inst == null) {
            inst = new Translations( );
        }
        return inst;
    }

    private void fillKeywords() {
        keywords.put( "local", "LCL" );
        keywords.put( "argument", "ARG" );
        keywords.put( "this", "THIS" );
        keywords.put( "that", "THAT" );
        keywords.put( "temp", "5" );
    }


    private void fillpop() {
        pops.put( DEFAULT, "@YYY\nD=A\n@XXX\nD=M+D\n@R14\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R14\nA=M\nM=D\n" );  //(local, argument, this, that, temp)
        pops.put( TEMP, "@YYY\nD=A\n@XXX\nD=A+D\n@R14\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R14\nA=M\nM=D\n" );  //(local, argument, this, that, temp)
        pops.put( POINTER_OR_STATIC, "@SP\nM=M-1\nA=M\nD=M\n@XXX\nM=D\n" ); //XXX is the target (fileName.num or THIS or THAT) (pointer and static)
        //TODO: POP CONSTANT ISNT LEGAL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }

    private void fillLabelCommands() {
        labelCommands.put( "label", "(CCC)\n" );
        labelCommands.put( "goto", "@CCC\n0;JMP\n" );
        labelCommands.put( "if-goto", "@SP\nM=M-1\nA=M\nD=M\n@CCC\nD;JNE\n" ); //pops (delete)
        //TODO: POP CONSTANT ISNT LEGAL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }

    private void fillpush() {
        pushs.put( DEFAULT, "@YYY\nD=A\n@XXX\nA=M+D\nD=M\n@SP\nA=M\nM=D\n@SP\nM=M+1\n" ); //(local, argument, this, that, temp)
        pushs.put( TEMP, "@YYY\nD=A\n@XXX\nA=A+D\nD=M\n@SP\nA=M\nM=D\n@SP\nM=M+1\n" ); //(local, argument, this, that, temp)
        pushs.put( POINTER_OR_STATIC, "@XXX\nD=M\n@SP\nA=M\nM=D\n@SP\nM=M+1\n" ); //XXX is the target (fileName.num or THIS or THAT) (pointer and static)
        pushs.put( CONSTANT, "@YYY\nD=A\n@SP\nA=M\nM=D\n@SP\nM=M+1\n" ); //CONSTANT
    }

    private void fillArithmatics() { //todo:fill
//        String biggestPositive = "32767"; // 0111111111111111
        String old_gt = "\n(Regular_LABEL)\n"+"@SP\nA=M\nD=M\n@SP\nM=M-1\nA=M\nD=M-D\nM=0\n@J_LABEL\nD;JLE\n@SP\nA=M\nM=-1\n(J_LABEL)\n@SP\nM=M+1\n"+"@End_LABEL\n0;JMP\n";
        String old_lt = "\n(Regular_LABEL)\n"+"@SP\nA=M\nD=M\n@SP\nM=M-1\nA=M\nD=M-D\nM=0\n@J_LABEL\nD;JGE\n@SP\nA=M\nM=-1\n(J_LABEL)\n@SP\nM=M+1\n"+"@End_LABEL\n0;JMP\n";
        Arithmetic.put( "add", "@SP\nM=M-1\nA=M\nD=M\n@SP\nA=M-1\nM=M+D\n" );
        Arithmetic.put( "sub", "@SP\nM=M-1\nA=M\nD=M\n@SP\nA=M-1\nM=M-D\n" ); //x - y
        Arithmetic.put( "neg", "@SP\nA=M-1\nM=!M\nM=M+1\n" ); //not(y) + 1
        //TODO increase counter by 1 each time you use lt,eq,gt
        Arithmetic.put( "lt", "@32767\nD=!A\n@SP\nM=M-1\nA=M\nD=M&D\n@R14\nM=D\n@32767\nD=!A\n@SP\nA=M-1\nD=M&D\n@R13\nM=D\n@R14\nD=D-M\n@Regular_LABEL\nD;JEQ\n@R14\nD=M\n@True_LABEL\nD;JEQ\n@SP\nA=M-1\nM=0\n@End_LABEL\n0;JMP"+old_lt+"(True_LABEL)\n@SP\nA=M-1\nM=-1\n@End_LABEL\n0;JMP\n(End_LABEL)\n" );
        Arithmetic.put( "eq", "@SP\nM=M-1\nA=M\nD=M\n@SP\nM=M-1\nA=M\nD=M-D\nM=0\n@J_LABEL\nD;JNE\n@SP\nA=M\nM=-1\n(J_LABEL)\n@SP\nM=M+1\n" );
        Arithmetic.put( "gt", "@32767\nD=!A\n@SP\nM=M-1\nA=M\nD=M&D\n@R14\nM=D\n@32767\nD=!A\n@SP\nA=M-1\nD=M&D\n@R13\nM=D\n@R14\nD=D-M\n@Regular_LABEL\nD;JEQ\n@R13\nD=M\n@True_LABEL\nD;JEQ\n@SP\nA=M-1\nM=0\n@End_LABEL\n0;JMP"+old_gt+"(True_LABEL)\n@SP\nA=M-1\nM=-1\n@End_LABEL\n0;JMP\n(End_LABEL)\n" );
        Arithmetic.put( "and", "@SP\nM=M-1\nA=M\nD=M\n@SP\nA=M-1\nM=M&D\n" );
        Arithmetic.put( "or", "@SP\nM=M-1\nA=M\nD=M\n@SP\nA=M-1\nM=M|D\n" );
        Arithmetic.put( "not", "@SP\nA=M-1\nM=!M\n" ); //not(y)

        {}
    }

    private int get_type(String memorySection) throws Exception {

        if (memorySection.equals( "temp" )) {
            return TEMP;
        } else if (memorySection.equals( "static" ) || memorySection.equals( "pointer" )) {
            return POINTER_OR_STATIC;
        } else if (memorySection.equals( "constant" )) {
            return CONSTANT;
        }else if (keywords.containsKey( memorySection )) {      //without temp kaeelo
                return DEFAULT;
        } else {
            throw new Exception( "invalid memory section" );

        }
    }

    public String get_pop(String fileName, String memorySection, String offset) throws Exception {
        int type = get_type( memorySection );
        if (type == CONSTANT) {
            throw new Exception( "cant pop to constant" );
        }
        if(memorySection.equals( "pointer" )){
            return pops.get( type ).replaceAll( "XXX", (offset.equals("0") ? "THIS" : "THAT") );
        }
        else if(memorySection.equals( "static" )){
            return pops.get( type ).replaceAll( "XXX", fileName+ "" +offset );
        }
        else if (type== DEFAULT || type == TEMP){

            return pops.get( type ).replaceAll( "XXX", keywords.get(memorySection)).replaceAll( "YYY", offset );
        }
        else {
            throw new Exception("Wrong Input");
        }
    }

    public String get_push(String fileName, String memorySection, String offset) throws Exception {
        int type = get_type(memorySection);
        if (type == CONSTANT) {
            return pushs.get(type).replaceAll("YYY", offset);
        }
        if (memorySection.equals("pointer")) {
            return pushs.get(type).replaceAll("XXX", (offset.equals("0") ? "THIS" : "THAT"));
        } else if (memorySection.equals("static")) {
            return pushs.get(type).replaceAll("XXX", fileName + "" + offset);
        } else if (type == DEFAULT || type ==TEMP) {
            return pushs.get(type).replaceAll("XXX", keywords.get(memorySection)).replaceAll("YYY", offset);
        } else {
            throw new Exception("Wrong Input");
        }
    }

    public String get_Arithmetic(String type) throws Exception {
        if (!Arithmetic.containsKey( type )) {
            throw new Exception( "invalid arithmetic" );
        } else {
            String res = Arithmetic.get( type ).replaceAll( "LABEL", "" + counter );
            if (type.equals( "lt" ) || type.equals( "eq" ) || type.equals( "gt" )) {
                //increase counter
                counter += 1;
            }
            return res;
        }
    }

    public String get_label_commands(String command, String label, boolean functionCall) throws Exception {
        if(label.equals( "IF_FALSE" )){
            System.out.println( );
        }
        if(labelCommands.containsKey(command)){
            // func_name$label instead of label if were inside of a function definition
            if(functionBeingDefined != null && !functionCall){
                label = functionBeingDefined + "\\$" + label;
            }
            return labelCommands.get(command).replaceAll("CCC",label);
        }
        else{
            throw new Exception(("invalid label"));
        }
    }

    public String func_declaration(String func_name, int num_params) throws Exception {
//        if(functionBeingDefined != null){
//            throw new Exception("Already inside of function definition");
//        }
//        if(!func_name.equals("Sys.init")) {
//            functionBeingDefined = func_name;
//            depth += 1;
//        }
        functionBeingDefined = func_name;
        function_param_num.put(func_name, num_params);
        String ret="";
        //setting local to zeroes
        for(int i=0; i<num_params; i++){
            ret += push_to_stack("returnAddress","0");
        }
        ret += "(" + func_name + ")\n";
        return ret ; //todo: ke$ha
    }

    public String func_call(String func_name, int num_args) throws Exception {
        String return_label ;
        if(functionBeingDefined == null){
            return_label = "Global" + "$ret."+ret_counter;
        }
        else{
            return_label = functionBeingDefined + "$ret."+ ret_counter ;
        }
//        if(!func_name.equals("Sys.init")) {
//            depth += 1;
//        }
        ret_counter += 1;
        //prepare stack
        String ret =push_to_stack("returnAddress",return_label);
        ret += push_to_stack("LCL",null)+push_to_stack("ARG", null)+
                push_to_stack("THIS", null)+push_to_stack("THAT", null);
        //TODO FORGOT ABOUT POINTER
        ret += "@SP\nD=M\n@"+(num_args+5)+"\nD=D-A\n@ARG\nM=D\n" ; // ARG = SP - num_args - 5
        ret += "@SP\nD=M\n@LCL\nM=D\n"; //LCL=SP

        //setting local to zeroes
//        for(int i=0; i<num_args; i++){ //todo: old
//        num_args = Math.max(num_args, function_param_num.get( func_name )); //todo: new new
        num_args = function_param_num.get( func_name ) + num_args; //todo: old new
//        num_args = function_param_num.get( func_name ); //todo: old new
        for(int i=0; i<num_args; i++){ //todo: new
            ret += push_to_stack("returnAddress","0");
        }
        ret += get_label_commands("goto",func_name,true);
        //add (ret_addr)
        ret += "("+return_label+")\n";


        return ret;
    }

    private String push_to_stack(String memSection, String ret_addr){
        if(memSection.equals("returnAddress")){
            return "@"+ret_addr+"\nD=A\n@SP\nM=M+1\nA=M-1\nM=D\n";
        }
        else{
            return "@"+memSection+"\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n";
        }
    }

    public String return_translation() throws Exception {
        String ret = "@LCL\nD=M\n@R13\nM=D\n";
        ret += "@R13\nD=M\n@5\nA=D-A\nD=M\n@R14\nM=D\n"; //R14 contains retAddress
        ret += "@SP\nM=M-1\nA=M\nD=M\n@ARG\nA=M\nM=D\n"; //*ARG = pop the stack
        ret += "@ARG\nD=M+1\n@SP\nM=D\n"; //SP = ARG + 1 //todo: this is original (basel
        //that
        ret += "@R13\nD=M\n@1\nA=D-A\nD=M\n@THAT\nM=D\n";
        // THIS
        ret += "@R13\nD=M\n@2\nA=D-A\nD=M\n@THIS\nM=D\n";
        // ARG
        ret += "@R13\nD=M\n@3\nA=D-A\nD=M\n@ARG\nM=D\n";
        // LCL
        ret += "@R13\nD=M\n@4\nA=D-A\nD=M\n@LCL\nM=D\n";
        //goto ret addr
        ret += "@R14\nA=M\n0;JMP\n"; //jump to ret_address
//        prev_depth = depth;
//        depth -= 1;
////        if(depth == 0 && prev_depth!= -1) {
//        if(depth == 0) {
//            functionBeingDefined = null;
//        }
        return ret;
    }







}
