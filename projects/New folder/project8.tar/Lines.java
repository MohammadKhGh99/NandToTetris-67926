import java.io.File;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * a class that takes a File in the constructor, if the file exists, and is not a directory, process its lines
 * (type was previously checked by the main class), delete empty lines, white spaces, and comments
 */
public class Lines {
    private static boolean init = false;
    private Translations VM_DATABASE = Translations.getTranslations();
    public ArrayList<String> lines = new ArrayList<>();
    public ArrayList<String> output = new ArrayList<>();
    private String fileName;


    //    private String labelRegex = "^\\((.+)\\)$"; //todo: global var
//    private String varRegex = "^@(.+)$"; //todo: check what is a legal symbol syntax
    private String numRegex = "\\d+";
    private Pattern num = Pattern.compile(numRegex);


    public Lines(File file, boolean scan) throws Exception {
        if (file.exists() && !file.isDirectory()) {
            this.lines = readLines(file);
            //scan
            //translate
            fileName = file.getName();
            if(!init && !scan) {
                init = true;
                add_init( ); // add bootStrap
            }
            if(!scan) {
                parse_all( );
            }else{
                scanLabels();
            }
        }
    }

    public void scanLabels() throws Exception {
        for (String line : this.lines) {
            String[] parts = line.split( " " );
            String[] first_part = line.split( " ", 2 );
            if (first_part[0].equals( "function" )) {
                String numParams = parts[parts.length - 1];
                if (!(num.matcher( numParams ).matches( ))) {
                    throw new Exception( "invalid function declaration: " + line );
                }
                // take function name into func_name
                String func_name = first_part[1].trim( );
                func_name = func_name.substring( 0, func_name.lastIndexOf( " " ) );

                Translations.getTranslations( ).function_param_num.put( func_name, Integer.parseInt( numParams ) );
            }
        }
    }

    /**
     * add sys.init
     */
    private void add_init() throws Exception {
//        if(!output.isEmpty()){
        output.add( 0,"@256\nD=A\n@SP\nM=D\n"+VM_DATABASE.func_call("Sys.init",0)+"//----------------------------------------\n" );
//        output.add( 0,"@256\nD=A\n@SP\nM=D\n"+"@Sys.init\n0;JMP\n"+"//----------------------------------------\n" );
//        }
    }

    /**
     * @param file a file of type .vm add its lines to the arraylist called lines,
     *             no empty lines, no spaces or comments.
     * @return the array list object containing the lines
     */
    static private ArrayList<String> readLines(File file) throws IOException {
        BufferedReader reader;
        ArrayList<String> lines = new ArrayList<>();
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            while (line != null) {
                line = line.replaceAll("//.*$", ""); //delete comments
                line = line.replaceAll("\\s+", " "); //replace all white spaces with a single white space
                line = line.trim(); //delete leading and trailing white spaces
                if (!line.isEmpty()) {
                    lines.add(line);
                }
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
        return lines;
    }

    public String parse_line(String line) throws Exception {
        String[] parts = line.split(" ");
        String[] first_part = line.split(" ", 2);
        if (first_part[0].equals("label") || first_part[0].equals("goto") || first_part[0].equals("if-goto")) {
            return VM_DATABASE.get_label_commands(first_part[0], first_part[1],false);
        }
        else if (first_part[0].equals("function")) {
            String numParams = parts[parts.length - 1];
            if (!(num.matcher(numParams).matches())) {
                throw new Exception("invalid function declaration: " + line);
            }
            // take function name into func_name
            String func_name = first_part[1].trim();
            func_name = func_name.substring(0, func_name.lastIndexOf(" "));
            return VM_DATABASE.func_declaration(func_name, Integer.parseInt(numParams));
        }
        else if (first_part[0].equals("call")) {
            String num_ARGS = parts[parts.length - 1];
            if (!(num.matcher(num_ARGS).matches())) {
                throw new Exception("invalid function call: " + line);
            }
            // take function name into func_name
            String called_func = first_part[1].trim();
            called_func = called_func.substring(0, called_func.lastIndexOf(" "));
            return VM_DATABASE.func_call(called_func, Integer.parseInt(num_ARGS)); //todo: we can add label here
        }
        else if (first_part[0].equals("return")) {
            return VM_DATABASE.return_translation(); //todo: we can add label here
        }
        //todo: when return is encountered, cancel the function declaration boolean in VM_DATABASE
        else if (parts.length == 3) {
            //push/pop operation
            // check validity of index 1 and 2
            if (!(num.matcher(parts[2]).matches())) {
                throw new Exception("invalid line: " + line);
            }
            //check push
            if (parts[0].equals("push")) {
                return VM_DATABASE.get_push(fileName, parts[1], parts[2]);
            }
            //check pop
            else if (parts[0].equals("pop")) {
                return VM_DATABASE.get_pop(fileName, parts[1], parts[2]);
            } else {
                throw new Exception(parts[0] + "not supported");
            }
        } else if (parts.length == 1) {
            //arithmetic operation
            return VM_DATABASE.get_Arithmetic(parts[0]);
        } else {

            throw new Exception("wrong command");

        }
    }

    private void parse_all() throws Exception {
        try {
            for (String line : lines) {
                output.add(parse_line(line));
                output.add("\n//------------------------------------------------------\n");
            }
        } catch (Exception e) {
            throw e;
        }
//        finally {
//            VM_DATABASE.reset_counter();
//        }
    }
//
//    public static void main(String[] args) throws IOException {
//        File f = new File( "C:\\Users\\basel\\Desktop\\nand2tetris\\projects\\07\\java\\StaticTest.vm" );
//        ArrayList<String>  l = Lines.readLines(f);
//        System.out.println( );
//    }
}
