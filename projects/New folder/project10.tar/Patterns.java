import java.util.regex.Pattern;

public class Patterns {
    static String identifier = "[A-Za-z_]\\w*";


    //statments
    static String returnRgex = "\\s*return\\s+([^;]+)?\\s*;\\s*";
    static Pattern returnPattern = Pattern.compile(returnRgex);

    static String doreg = "\\s*do\\s+([^;]+)\\s*;\\s*";
    static Pattern doPattern = Pattern.compile(doreg);

    static String whileRegex = "\\s*while\\s*\\(([^\\)]+)\\)\\s*\\{(.*)\\}\\s*";
    static Pattern whilePattern = Pattern.compile(whileRegex);

    static String ifregex = "\\s*if\\s*\\(([^\\)]+)\\)\\s*\\{([^\\}]*)\\}\\s*(else\\s*\\{([^\\}]*)\\}\\s*)?";
    static Pattern  ifPattern = Pattern.compile(ifregex);

    static String letRegex  = "\\s*let\\s+("+identifier+")\\s*(\\[(.+)\\])?\\s*=\\s*([^;]+);\\s*";
    static Pattern letPattern  = Pattern.compile(letRegex);

    static String statementRegex = "\\s*("+letRegex+"|"+ifregex+"|"+whileRegex+"|"+doreg+"|"+returnRgex+")\\s*";
    static Pattern statementPattern = Pattern.compile(statementRegex);

    static String statementsRegex = "\\s*("+statementRegex+")*\\s*";
    static Pattern statementsPattern = Pattern.compile(statementsRegex);


    static String classDefinitionRegex = "\\s*class\\s+("+identifier+")\\s*\\{(.*)\\}\\s*";
    static Pattern classDefinitionPattern = Pattern.compile(classDefinitionRegex);

    static String classVarDecRegex = "\\s*(static|field)\\s+([^, ]+)\\s+("+identifier+")((\\s*,\\s*("+identifier+"))*)\\s*;";
    static Pattern classVarDecPattern = Pattern.compile(classVarDecRegex);

    static String typeRegex = "(int|char|boolean|"+identifier+")"; //(int|char|boolean|[A-Za-z_]\w*)
    static Pattern typePattern = Pattern.compile(typeRegex);

    static String subroutineDecRegex = "\\s*(constructor|function|method)\\s+(void|(int|char|boolean|[A-Za-z_]\\w*))\\s+([A-Za-z_]\\w*)\\s*\\(([^\\)]*)\\)\\s*(\\{\\s*(.*)\\s*\\}$)";
    static Pattern subroutineDecPattern = Pattern.compile(subroutineDecRegex);

    static String parameterListRegex = "("+typeRegex+"\\s+"+identifier+"(\\s*,\\s*"+typeRegex+"\\s+"+identifier+")*)?";
    static Pattern parameterListPattern = Pattern.compile(parameterListRegex);

    static String varDecRegex = "\\s*var\\s+"+typeRegex+"\\s+("+identifier+")\\s*((,\\s*("+identifier+")\\s*)*)\\s*;\\s*";
    static Pattern varDecPattern = Pattern.compile(varDecRegex);

    static String subroutineBodyRegex = "\\s*\\{\\s*("+varDecRegex+")*\\s*("+statementsRegex+")\\s*}\\s*";
    static Pattern subroutineBodyPattern = Pattern.compile(subroutineBodyRegex);

    // expressions
    static String callSubroutineRegex = "^\\s*((([A-Za-z_]\\w*)\\.)?)([A-Za-z_]\\w*)\\s*\\((.*)\\)$\\s*";
    static Pattern callSubroutinePattern = Pattern.compile(callSubroutineRegex);

    static String keywordConstantRegex = "\\s*(true|false|null|this)\\s*";
    static Pattern keywordConstantPattern = Pattern.compile(keywordConstantRegex);

    static String termRegex = "\\s*((\\d+)|(\\\"[^\\\"\\n]*\\\")|\\s*(true|false|null|this)\\s*|(^\\s*((([A-Za-z_]\\w*)\\.)?)([A-Za-z_]\\w*)\\s*\\((.*)\\)$\\s*)|(([A-Za-z_]\\w*)(\\[(.+)\\])?)|(\\((.+)\\))|((-|~)(.+)))";
    static Pattern termPattern = Pattern.compile(termRegex);

    static String opRegex = "^\\s*((\\+|-|\\*|\\/|&|\\||>|<|=){1,2})\\s*(.*)"; //todo: remove {1,2} **********************************
    static Pattern opPattern = Pattern.compile(opRegex);

    static String expressionRegex = termRegex+"(("+opRegex+"(.+))*)";
    static Pattern expressionPattern = Pattern.compile(expressionRegex);

    static String expression_first_Regex = "^("+termRegex+")\\s*(.*)";
    static Pattern expression_first_Pattern = Pattern.compile(expression_first_Regex);

}
