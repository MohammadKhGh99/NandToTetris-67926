import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.*;

public class JackAnalyzer {
    private final static String TYPE = "jack";

    public static void main(String[] args)throws Exception
    {
        String path = "";
        if(args.length == 1){
            path = args[0];
        }
        else if(args.length > 1 ){
            throw new Exception();
        }
        File pathInput = new File(path).getCanonicalFile();
        if(pathInput.isDirectory()){
            //translate lines
            listAllFiles(pathInput);
        }
        else if(pathInput.exists()) {
            int last = pathInput.getCanonicalPath().lastIndexOf(".jack");
            if (last == -1){
                return;
            }
            //translate lines
            fileProcess(pathInput, last);
        }
        else{
            return;
        }

    }

    public static void listAllFiles(File folder) throws IOException, TransformerException, ParserConfigurationException {
        File[] fileNames = folder.listFiles();
        assert fileNames != null;
        for (File file : fileNames) {
            int last = file.getCanonicalPath().lastIndexOf(".jack");
            if (last == -1){
                continue;
            }
            fileProcess( file, last );
        }
    }

    public static void fileProcess(File file, int last) throws IOException {
        String type = file.getCanonicalPath().substring(last+1);
        if(TYPE.equals(type)){
            try {
                String outputPath = file.getCanonicalPath().substring(0,last) + ".xml";
                String lines = readLines( file );  //todo: merge and clean lines (make sure)
                new Analyzer(lines, outputPath);
            }
            catch (Exception e){
                //don't do anything ..
                System.out.println(e.getMessage()); //todo: delete
                for(StackTraceElement t: e.getStackTrace()){
                    System.out.println(t); //todo: delete
                }

            }
        }
    }

//    /**
//     * @param file a file of type .vm add its lines to the arraylist called lines,
//     *             no empty lines, no spaces or comments.
//     * @return the array list object containing the lines
//     */
////    static private ArrayList<String> readLines(File file) throws IOException {
//    static private String readLines(File file) throws IOException {
//        BufferedReader reader;
////        ArrayList<String> lines = new ArrayList<>();
//        String lines = "";
//        try {
//            reader = new BufferedReader( new FileReader( file ) );
//            String line = reader.readLine( );
//            while (line != null) {
//                lines = lines.replaceAll( "//.*$", "" ); //delete comments some comment
//                line = line.trim( ); //delete leading and trailing white spaces
//                if (!line.isEmpty( )) {
////                    lines.add(line);
//                    lines += " "+line;
//                }
//                // read next line
//                line = reader.readLine( );
//            }
//            reader.close( );
//        } catch (IOException e) {
//            e.printStackTrace( );
//            throw e;
//        }
////        lines = lines.replaceAll( "\n+", "" ); //delete newLines
//        lines = lines.replaceAll( "\\/\\*.*?\\/", "" ); //delete comments /* some comment*/
//        lines = lines.replaceAll( "\\s+", " " ); //replace all white spaces with a single white space
//        return lines;
//    }
//
//}

    /**
     * @param file a file of type .vm add its lines to the arraylist called lines,
     *             no empty lines, no spaces or comments.
     * @return the array list object containing the lines
     */
//    static private ArrayList<String> readLines(File file) throws IOException {
    static private String readLines(File file) throws IOException {
        BufferedReader reader;
//        ArrayList<String> lines = new ArrayList<>();
        String lines = "";
        try {
            reader = new BufferedReader( new FileReader( file ) );
            String line = reader.readLine( );
            while (line != null) {
//                lines = lines.replaceAll( "//.*$", "" ); //delete comments some comment
                line = clean_comments(line).trim( ); //delete leading and trailing white spaces and comments
                if (!line.isEmpty( )) {
//                    lines.add(line);
                    lines += " "+line;
                }
                // read next line
                line = reader.readLine( );
            }
            reader.close( );
        } catch (IOException e) {
            e.printStackTrace( );
            throw e;
        }
//        lines = lines.replaceAll( "\n+", "" ); //delete newLines
//        lines = lines.replaceAll( "\\/\\*.*?\\/", "" ); //delete comments /* some comment*/
        lines = clean_multi_comments(lines);
        lines = lines.replaceAll( "\\s+", " " ); //replace all white spaces with a single white space
        return lines;
    }

    public static String clean_comments(String x){
        String res = "";
        int quot = 0;
        for(int i=0 ; i < x.length() ; i++){
            if(x.charAt(i) == '"'){
                quot = (quot+1)%2;
            }
            if(quot == 0 && i < x.length() - 1 && x.substring(i,i+2).equals("//")){
                break;
            }
            res += x.charAt(i);
        }
        return res;
    }

    public static String clean_multi_comments(String x){
        String res = "";
        int quot = 0;
        boolean stop = false;
        for(int i=0 ; i < x.length() ; i++){
            if(x.charAt(i) == '"'){
                quot = (quot+1)%2;
            }
            if(quot == 0 && i < x.length() - 1 && x.substring(i,i+2).equals("/*")){
                stop=true;
                continue;
            }
            if(quot == 0 && i < x.length() - 1 && stop && x.substring(i,i+2).equals("*/")){
                stop=false;
                i+=1;
                continue;
            }
            if(!stop){
                res += x.charAt(i);
            }
        }
        return res;
    }
}
