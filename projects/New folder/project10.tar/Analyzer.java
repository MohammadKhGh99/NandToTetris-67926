import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


public class Analyzer {
    static Document DOC;

    static HashSet<String> keywords = new HashSet<>();
    static HashSet<String> symbols = new HashSet<>();
    ArrayList<Element> tokenized_tags;


    public static void fill_keywords() {
        keywords.add("class");
        keywords.add("constructor");
        keywords.add("function");
        keywords.add("method");
        keywords.add("if");
        keywords.add("else");
        keywords.add("while");
        keywords.add("field");
        keywords.add("static");
        keywords.add("var");
        keywords.add("let");
        keywords.add("do");
        keywords.add("return");
        keywords.add("true");
        keywords.add("false");
        keywords.add("null");
        keywords.add("this");
        keywords.add("int");
        keywords.add("char");
        keywords.add("boolean");
        keywords.add("void");

    }

    public static void fill_symbols() {
        symbols.add("{");
        symbols.add("}");
        symbols.add("(");
        symbols.add(")");
        symbols.add("[");
        symbols.add("]");
        symbols.add(".");
        symbols.add(",");
        symbols.add(";");
        symbols.add("+");
        symbols.add("-");
        symbols.add("*");
        symbols.add("/");
        symbols.add("&");
        symbols.add("|");
        symbols.add(">");
        symbols.add("<");
        symbols.add("=");
        symbols.add("~");
    }

    Analyzer(String lines, String outputPath) throws TransformerException, ParserConfigurationException {
        tokenized_tags = new ArrayList<Element>();
        // 1.Create a DocumentBuilder instance
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbuilder = dbFactory.newDocumentBuilder();

        // 2. Create a Document from the above DocumentBuilder.
        DOC = dbuilder.newDocument();

        if (keywords.isEmpty() || symbols.isEmpty()) {
            // fill databases
            fill_keywords();
            fill_symbols();
        }
        tokenized_tags = tokenizing(lines);
        if (tokenized_tags.size() == 1) {
            DOC.appendChild(tokenized_tags.get(0));

            // write content into xml file
            write_to_xml(DOC, outputPath);
        } else {
            System.out.println("error in array size");
        }

    }

    public static void write_to_xml(Document document, String outputFile) throws TransformerException {

        // write content into xml file

        // 4. Create a new Transformer instance and a new DOMSource instance.
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(document);

        // 5. Create a new StreamResult to the output stream you want to use.
//        StreamResult result = new StreamResult(new File("C:\\Users\\asad\\Desktop\\HUJI\\HUJI\\Year-2\\Semester-1\\67925-NAND2Tetris\\projects\\Java\\10\\src\\users.xml"));
        StreamResult result = new StreamResult(new File(outputFile));
        // StreamResult result = new StreamResult(System.out); // to print on console
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        // 6. Use transform method to write the DOM object to the output stream.
        transformer.transform(source, result);
    }

    public static Element make_element(Document document, String tagName, String text) {
        // root element
        Element elm = document.createElement(tagName);
        if (text.isEmpty()) {
            elm.appendChild(document.createTextNode(""));
        } else {
            elm.appendChild(document.createTextNode(" " + text + " "));
        }
        return elm;
    }

    public static Element add_under_elm(Element add_to, Element to_add) {
        add_to.appendChild(to_add);
        //return whats just been added
        return to_add;
    }


    public static Element add_all_helper(ArrayList<Element> sub_elements, String capturing_tag) {
        Element e;
        if (sub_elements.isEmpty()) {
            e = make_element(DOC, capturing_tag, System.lineSeparator());
//            e = make_element(DOC, capturing_tag, "" );
        } else {
            e = make_element(DOC, capturing_tag, "");
        }
        for (Element element : sub_elements) {
            add_under_elm(e, element);
        }
        return e;
    }


    static public ArrayList<Element> tokenizing(String part) {
        if (part == null) {
            return null;
        }
        Element e = null;
        ArrayList<Element> elements = new ArrayList<>();
        String token = "";
        //add space to end of string
        part = part.trim() + " ";
        boolean statements = false;
        Element statementss = null;
        for (int i = 0; i < part.length(); i++) {
            char c = part.charAt(i);

            if (symbols.contains(token)) {
                if (statements) {
                    elements.add(statementss);
                    statements = false;
                    statementss = null;
                }
//                if(token.trim().equals(">")){
//                    elements.add(make_element(DOC, "symbol", "&gt;"));
//                }
//                else if(token.trim().equals("<")){
//                    elements.add(make_element(DOC, "symbol", "&lt;"));
//                }
//                else if(token.trim().equals("&")){
//                    elements.add(make_element(DOC, "symbol", "&amp;"));
//                }
//                else {
//                    elements.add(make_element(DOC, "symbol", token.trim()));
//                }
                elements.add(make_element(DOC, "symbol", token.trim()));
                token = "";
            } else if (token.startsWith("\"") && token.endsWith("\"") && !token.equals("\"")) {
                if (statements) {
                    elements.add(statementss);
                    statements = false;
                    statementss = null;
                }
                elements.add(make_element(DOC, "stringConstant", token.substring(1, token.length() - 1)));
                token = "";
            }
            if (c == ' ' || symbols.contains(Character.toString(c))) {  // separators
                if (symbols.contains(token)) {
                    if (statements) {
                        elements.add(statementss);
                        statements = false;
                        statementss = null;
                    }
//                    if(token.trim().equals(">")){
//                        elements.add(make_element(DOC, "symbol", "&gt;"));
//                    }
//                    else if(token.trim().equals("<")){
//                        elements.add(make_element(DOC, "symbol", "&lt;"));
//                    }
//                    else if(token.trim().equals("&")){
//                        elements.add(make_element(DOC, "symbol", "&amp;"));
//                    }
//                    else {
//                        elements.add(make_element(DOC, "symbol", token.trim()));
//                    }
                    elements.add(make_element(DOC, "symbol", token.trim()));
                    token = "";
                } else if (keywords.contains(token)) {
                    int end = -1;
                    switch (token) {
                        //statements
                        case "return":
                        case "do":
                        case "while":
                        case "if":
                        case "let": {
                            switch (token) {
                                case "return": {
                                    end = part.indexOf(";", i);
                                    e = add_all_helper(tokenize_return(token + part.substring(i, end + 1)), "returnStatement");
                                    i = end;
                                    c = ' '; //todo: to remove duplicate ;
                                    break;
                                }
                                case "do": {
                                    end = part.indexOf(";", i);
                                    e = add_all_helper(tokenize_do(token + part.substring(i, end + 1)), "doStatement");
                                    i = end;
                                    break;
                                }
                                case "let": {
                                    end = part.indexOf(";", i);
                                    e = add_all_helper(tokenize_let(token + part.substring(i, end + 1)), "letStatement");
                                    i = end;
                                    break;
                                }
                                // curly brackets
                                case "if": {
                                    end = find_brackets_balanced_if(part, i, true);
                                    e = add_all_helper(tokenize_if_else(token + part.substring(i, end)), "ifStatement");
                                    i = end - 1;
                                    c=' ';
                                    break;
                                }
                                case "while": {
                                    end = find_brackets_balanced_if(part, i, false);
                                    e = add_all_helper(tokenize_while(token + part.substring(i, end)), "whileStatement");
                                    i = end - 1;
                                    c=' ';
                                    break;
                                }
                            }
                            if (!statements) {
                                statements = true;
                                statementss = make_element(DOC, "statements", "");
                                add_under_elm(statementss, e);
                            } else {
                                add_under_elm(statementss, e);
                            }
                            break;
                        }
                        default:
                            if (statements) {
                                elements.add(statementss);
                                statements = false;
                                statementss = null;
                            }
                            switch (token) {
                                case "class": {
                                    end = find_brackets_balanced_if(part, i, false);
                                    e = add_all_helper(tokenize_class(token + part.substring(i, end)), "class");
                                    elements.add(e);
                                    e = null;
                                    i = end - 1;
                                    break;
                                }
                                case "constructor":
                                case "function":
                                case "method": {
                                    end = find_brackets_balanced_if(part, i, false);
                                    e = add_all_helper(tokenize_subroutineDec(token + part.substring(i, end)), "subroutineDec");
                                    elements.add(e);
                                    e = null;
                                    i = end - 1;
                                    break;
                                }
                                case "var": {
                                    end = part.indexOf(";", i);
                                    e = add_all_helper(tokenize_VarDec(token + part.substring(i, end + 1)), "varDec");
                                    elements.add(e);
                                    e = null;
                                    i = end;
                                    break;
                                }
                                case "static":
                                case "field": {
                                    end = part.indexOf(";", i);
                                    e = add_all_helper(tokenize_classVarDec(token + part.substring(i, end + 1)), "classVarDec");
                                    elements.add(e);
                                    e = null;
                                    i = end;
                                    break;
                                }
                                case "true":
                                case "false":
                                case "null":
                                case "this": {
                                    elements.add(make_element(DOC, "keyword", token.trim()));
                                    break;
                                }
                                default:
                                    if (!(c == ' ' && token.trim().equals(""))) {
                                        token += c;
                                    }
                                    continue;
                            }
                    }
                    token = "";

                } else if (Pattern.compile(Patterns.identifier).matcher(token).matches()) {
                    if (statements) {
                        elements.add(statementss);
                        statements = false;
                        statementss = null;
                    }
                    elements.add(make_element(DOC, "identifier", token.trim()));
                    token = "";
                } else if (Pattern.compile("\\d+").matcher(token).matches()) {
                    if (statements) {
                        elements.add(statementss);
                        statements = false;
                        statementss = null;
                    }
                    elements.add(make_element(DOC, "integerConstant", token.trim()));
                    token = "";
                }
            }
            if (!(c == ' ' && token.trim().equals(""))) {
                token += c;
            }
        }
        if (statements) {
            elements.add(statementss);
        }
        return elements;
    }


    /**
     * @param text    the string the search through
     * @param begin   the beginning index to start looking from (any index before the brackets)
     * @param if_else if true then the function looks for 'else' after the brackets close
     * @return index+1 of the index of the last bracket that's balanced
     */
    public static int find_brackets_balanced_if(String text, int begin, boolean if_else) {
        boolean found = false;
        int balance = 0;
        int i = begin;
        while (!(balance == 0 && found)) {
            if (text.charAt(i) == '{') {
                found = true;
                balance += 1;
            } else if (text.charAt(i) == '}') {
                balance -= 1;
            }
            i += 1;
        }
        //if were looking for the brackets of an if else statement then we enter this part
        if (if_else) {
            //parse the next 4 letter
            int j = i;
            if (text.charAt(i) == ' ') //if there's a space update the index
                j += 1;
            if (text.length() >= j + 4 && text.substring(j, j + 4).equals("else")) { //check if the next word is 'else'
                return find_brackets_balanced_if(text, j, false);
            }
        }
        return i;
    }

    /*
    statements
    */
    public static ArrayList<Element> tokenize_if_else(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        boolean isThereElse;
        int beginKos = text.indexOf("(");
        int beginMes = text.indexOf("{");
        String ifExp = text.substring(beginKos, beginMes).trim();
        ifExp = ifExp.substring(1, ifExp.length() - 1).trim();
        int endMes = find_brackets_balanced_if(text, 0, false);
        String ifState = text.substring(beginMes, endMes).trim();
        ifState = ifState.substring(1, ifState.length() - 1).trim();
        String elseState = text.substring(endMes - 1).trim();
        elseState = elseState.substring(1).trim();
        String elseStateWithout = "";
        if (elseState.isEmpty()) {
            //no else statement existst at all
            isThereElse = false;
        } else {
            isThereElse = true;
            int beginMesElse = elseState.indexOf("{");
            elseStateWithout = elseState.substring(beginMesElse).trim();
            elseStateWithout = elseStateWithout.substring(1, elseStateWithout.length() - 1).trim();
        }
        elements.add(make_element(DOC, "keyword", "if"));
        elements.add(make_element(DOC, "symbol", "("));
        Element e = add_all_helper(expression(ifExp), "expression");
        elements.add(e);
        elements.add(make_element(DOC, "symbol", ")"));
        elements.add(make_element(DOC, "symbol", "{"));
        if (!ifState.isEmpty()) {
            elements.add(tokenizing(ifState).get(0));
        } else {
            elements.add(make_element(DOC, "statements",System.lineSeparator() ));
//            elements.add(make_element(DOC, "statements", ""));
//            elements.add(make_element(DOC, "statements", ""));
        }
        elements.add(make_element(DOC, "symbol", "}"));
        if (isThereElse) {
            elements.add(make_element(DOC, "keyword", "else"));
            elements.add(make_element(DOC, "symbol", "{"));
            if (!elseStateWithout.isEmpty()) {
                elements.add(tokenizing(elseStateWithout).get(0));
            } else {
//                elements.add(make_element(DOC, "statements",System.lineSeparator() ));
//                elements.add(make_element(DOC, "statements", ""));
                elements.add(make_element(DOC, "statements", System.lineSeparator()));
            }
            elements.add(make_element(DOC, "symbol", "}"));
        }
        return elements;
    }

    public static ArrayList<Element> tokenize_while(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        int beginKos = text.indexOf("(");
        int beginMes = text.indexOf("{");
        String whileExp = text.substring(beginKos, beginMes).trim();
        whileExp = whileExp.substring(1, whileExp.length() - 1).trim();
        String whileState = text.substring(beginMes).trim();
        whileState = whileState.substring(1, whileState.length() - 1).trim();
        elements.add(make_element(DOC, "keyword", "while"));
        elements.add(make_element(DOC, "symbol", "("));
        Element e = add_all_helper(expression(whileExp), "expression");
        elements.add(e);
        elements.add(make_element(DOC, "symbol", ")"));
        elements.add(make_element(DOC, "symbol", "{"));
        if (!whileState.isEmpty()) {
            elements.add(tokenizing(whileState).get(0));
        } else {
//            elements.add(make_element(DOC, "statements",System.lineSeparator() ));
//            elements.add(make_element(DOC, "statements", ""));
            elements.add(make_element(DOC, "statements", System.lineSeparator()));
        }
        elements.add(make_element(DOC, "symbol", "}"));
        return elements;
    }

    public static ArrayList<Element> tokenize_let(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        if(text.contains("let a[b[a")){
            System.out.print("");
        }
        Matcher m = Patterns.letPattern.matcher(text);
        elements.add(make_element(DOC, "keyword", "let"));

        if (m.find()) {
            elements.add(make_element(DOC, "identifier", m.group(1).trim()));
            if (m.group(2) != null) {
                elements.add(make_element(DOC, "symbol", "["));
                Element e = add_all_helper(expression(m.group(3)), "expression");
                elements.add(e);

                elements.add(make_element(DOC, "symbol", "]"));
            }
            elements.add(make_element(DOC, "symbol", "="));
            Element e = add_all_helper(expression(m.group(4)), "expression");
            elements.add(e);

            elements.add(make_element(DOC, "symbol", ";"));
        }
        return elements;
    }

    public static ArrayList<Element> tokenize_do(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.doPattern.matcher(text);
        elements.add(make_element(DOC, "keyword", "do"));
        if (m.find()) {
            //subrotine call
            elements.addAll(callSubroutine(m.group(1)));
        }
        elements.add(make_element(DOC, "symbol", ";"));
        return elements;
    }

    public static ArrayList<Element> tokenize_return(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.returnPattern.matcher(text);
        elements.add(make_element(DOC, "keyword", "return"));
        if (m.find()) {
            if (m.group(1) != null) {
                Element e = add_all_helper(expression(m.group(1)), "expression");
                elements.add(e);

            }
        }
        elements.add(make_element(DOC, "symbol", ";"));
        return elements;
    }

    /*
    program structute
     */
    public static ArrayList<Element> tokenize_class(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.classDefinitionPattern.matcher(text);
        elements.add(make_element(DOC, "keyword", "class"));
        if (m.find()) {
            elements.add(make_element(DOC, "identifier", m.group(1).trim()));
            elements.add(make_element(DOC, "symbol", "{"));
            if (m.group(2) != null) {
                elements.addAll(tokenizing(m.group(2)));
            }
        }
        elements.add(make_element(DOC, "symbol", "}"));
        return elements;
    }


    public static ArrayList<Element> tokenize_classVarDec(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.classVarDecPattern.matcher(text);
        if (m.find()) {
            elements.add(make_element(DOC, "keyword", m.group(1).trim()));
            if (keywords.contains(m.group(2).trim())) {
                elements.add(make_element(DOC, "keyword", m.group(2).trim()));
            } else {
                elements.add(make_element(DOC, "identifier", m.group(2).trim()));
            }
            elements.add(make_element(DOC, "identifier", m.group(3).trim()));
            if (m.group(4) != null && !m.group(4).trim().equals("")) {
                for (String tok : m.group(4).substring(1).split(",")) {
                    elements.add(make_element(DOC, "symbol", ","));
                    elements.add(make_element(DOC, "identifier", tok.trim()));
                }
            }
        }
        elements.add(make_element(DOC, "symbol", ";"));
        return elements;
    }

    public static ArrayList<Element> tokenize_subroutineDec(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.subroutineDecPattern.matcher(text);
        if (m.find()) {
            elements.add(make_element(DOC, "keyword", m.group(1).trim()));
            if (keywords.contains(m.group(2).trim())) {
                elements.add(make_element(DOC, "keyword", m.group(2).trim()));
            } else {
                elements.add(make_element(DOC, "identifier", m.group(2).trim()));
            }
            elements.add(make_element(DOC, "identifier", m.group(4).trim()));
            elements.add(make_element(DOC, "symbol", "("));
            Element paramL;
            if (m.group(5) != null && !m.group(5).trim().equals("")) {
                paramL = make_element(DOC, "parameterList", "");
                boolean first = true;
                for (String tok : m.group(5).trim().split(",")) {
                    if (!first) {
                        add_under_elm(paramL, make_element(DOC, "symbol", ","));
                    } else {
                        first = false;
                    }
                    String[] parts = tok.trim().split("\\s+");
                    String type = parts[0];
                    String name = parts[1];
                    if (keywords.contains(type)) {
                        add_under_elm(paramL, make_element(DOC, "keyword", type.trim()));
                    } else {
                        add_under_elm(paramL, make_element(DOC, "identifier", type.trim()));
                    }
                    add_under_elm(paramL, make_element(DOC, "identifier", name.trim()));
                }
            } else {
                paramL = make_element(DOC, "parameterList", System.lineSeparator());
//                paramL = make_element(DOC, "parameterList","" );
            }
            elements.add(paramL);
            elements.add(make_element(DOC, "symbol", ")"));
            if (m.group(6) != null) {       //fix this mofordenaasjnsdvkjbasdkjlvbadskjbckl
                Element e = add_all_helper(tokenizing(m.group(6)), "subroutineBody");
                elements.add(e);
            }
        }
        return elements;
    }

    public static ArrayList<Element> tokenize_VarDec(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.varDecPattern.matcher(text);
        elements.add(make_element(DOC, "keyword", "var"));
        if (m.find()) {
            if (keywords.contains(m.group(1).trim())) {
                elements.add(make_element(DOC, "keyword", m.group(1).trim()));
            } else {
                elements.add(make_element(DOC, "identifier", m.group(1).trim()));
            }
            elements.add(make_element(DOC, "identifier", m.group(2).trim()));
            if (m.group(3) != null && !m.group(3).trim().equals("")) {
                for (String tok : m.group(3).substring(1).split(",")) {
                    elements.add(make_element(DOC, "symbol", ","));
                    elements.add(make_element(DOC, "identifier", tok.trim()));
                }
            }
        }
        elements.add(make_element(DOC, "symbol", ";"));
        return elements;
    }

    public static ArrayList<Element> callSubroutine(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        Matcher m = Patterns.callSubroutinePattern.matcher(text);
        if (m.find()) {
            if (m.group(2) != null) {
                //send 3 to tokenizer // (class|var) identifier
                elements.addAll(tokenizing(m.group(3)));
                //add .
                elements.add(make_element(DOC, "symbol", "."));
            }
            //send 4 to tokenizer // subname
            elements.addAll(tokenizing(m.group(4)));
            //add (
            elements.add(make_element(DOC, "symbol", "("));
            //send 5 to expressionList //explst
            Element e = add_all_helper(expression_list(m.group(5)), "expressionList");
            elements.add(e);
            //add )
            elements.add(make_element(DOC, "symbol", ")"));
        }
        return elements;
    }


    public static ArrayList<Element> term_tokinizer(String text) {
        ArrayList<Element> elements = new ArrayList<>();
        if (text.contains("getXCannon")){
            System.out.print("");
        }
        Matcher m = Patterns.termPattern.matcher(text);
        if (m.find()) {
            if (m.group(5) != null) { // subroutine call (hi.name()
                elements.addAll(callSubroutine(m.group(5)));
            } else if (m.group(11) != null) { //x[exp]
                //send 12 to tokenizer  //x
                elements.addAll(tokenizing(m.group(12)));
                if (m.group(13) != null) { //[exp]
                    //add [
                    elements.add(make_element(DOC, "symbol", "["));
                    //send 14 to expression //exp
                    Element e = add_all_helper(expression(m.group(14)), "expression");
                    elements.add(e);
                    //add ]
                    elements.add(make_element(DOC, "symbol", "]"));
                }
            } else if (m.group(15) != null) { //(exp)
                //add (
                elements.add(make_element(DOC, "symbol", "("));
                //send 16 to expression //exp
                Element e = add_all_helper(expression(m.group(16)), "expression");
                elements.add(e);
                elements.add(make_element(DOC, "symbol", ")"));

            } else if (m.group(17) != null) { //(-|~)term
                //add 18 //(-|~)
                elements.add(make_element(DOC, "symbol", m.group(18).trim()));
                //send 19 to term_tokinizer (self) //term
                Element e = add_all_helper(term_tokinizer(m.group(19)), "term");
                elements.add(e);
            } else {
                //send to tokenizing (big) function
                elements.addAll(tokenizing(text));
            }

        }

        return elements;
    }

    /**
     * @param text the string the search through
     * @return index+1 of the index of the last bracket that's balanced
     */
    public static int find_brackets_balanced(String text) {
        boolean found = false;
        int balance = 0;
        int i = 0;
        while (!(balance == 0 && found)) {
            if (text.charAt(i) == '(') {
                found = true;
                balance += 1;
            } else if (text.charAt(i) == ')') {
                balance -= 1;
            }
            i += 1;
        }
        return i;
    }

    /**
     * @param text the string the search through
     * @return index+1 of the index of the last bracket that's balanced
     */
    public static int find_temp(String text) {
        boolean found=false;
        int balance1 = 0; //(
        int balance2 = 0; //[
        int i = 0;
        while (balance1 >=0 && balance2>=0 && i<text.length()) {
            if (text.charAt(i) == '(') {
                found=true;
                balance1 += 1;
            }
            else if (text.charAt(i) == ')') {
                balance1 -= 1;
            }
            if (text.charAt(i) == '[') {
                found=true;
                balance2 += 1;
            }
            else if (text.charAt(i) == ']') {
                balance2 -= 1;
            }
            if(balance1 ==0 && balance2 == 0 && found){
                return i+1;
            }
            i += 1;
        }
        return i;
    }

    /**
     * @param text the string the search through
     * @return index+1 of the index of the last bracket that's balanced
     */
    public static int find_comma(String text, int index) {
        int balance1 = 0; //(
        int balance2 = 0; //[
        int i = index;
        int quot = 0;
        while (i<text.length()) {
            if(text.charAt(i) == '"'){
                quot = (quot+1)%2;
            }
            else if(quot == 0) { //if outside a quote
                if (text.charAt(i) == '(') {
                    balance1 += 1;
                } else if (text.charAt(i) == ')') {
                    balance1 -= 1;
                }
                if (text.charAt(i) == '[') {
                    balance2 += 1;
                } else if (text.charAt(i) == ']') {
                    balance2 -= 1;
                }
                if (balance1 == 0 && balance2 == 0 && text.charAt(i) == ',') {
                    return i;
                }
            }
            i += 1;
        }
        return i;
    }

    public static ArrayList<Element> expression(String text) {
        if(text.contains("ADMIRAL")){
            System.out.print("");
        }
        ArrayList<Element> elements = new ArrayList<>();
        if (text.trim().startsWith("\"") && text.trim().endsWith("\"") && !text.trim().equals(
                "\"")){
            Element e = add_all_helper(term_tokinizer(text.trim()), "term");
            elements.add(e);
            return elements;
        }
        Matcher m = Patterns.expression_first_Pattern.matcher(text);

        if (m.find()) {
            int end = m.end(1);
            int nnn = find_temp(m.group(1));
            String new_Group;
            if(nnn < end){
                new_Group = m.group(1).substring(0,nnn);
                end=nnn;
            }
            else {
                //tokenize first term of expression m.group(1)
                new_Group = m.group(1);
            }
//            if (m.group(1).trim().charAt(0) == '(') {
//                end = find_brackets_balanced(m.group(1));
//                new_Group = new_Group.substring(0, end);
//            }
            //todo: fixed in lib .**************************************************************************************************
            String rest = text.substring(end).trim();
            if(!rest.isEmpty() && rest.charAt(0)=='.'){
                rest = rest.substring(1).trim();
                m = Patterns.expression_first_Pattern.matcher(rest);
                if (m.find()) {

                    end = m.end(1);
                    new_Group += "." + m.group(1);
                    text = rest.substring(end).trim();
                    //todo: update end
                }
                if (!text.isEmpty() && text.trim().charAt(0) == '(') {
                    end = find_brackets_balanced(text);
                    new_Group += text.substring(0, end);
                    text = text.substring(end).trim(); //todo: this is old dont delete 2*******

                }

                if (text.length() > end) {
//                    text = text.substring(end).trim(); //todo: this is old dont delete 2*******
                }
                else {
//                    System.out.print("mohaha");
                }

            }
            else{
                if (new_Group.trim().charAt(0) == '(') {
                    end = find_brackets_balanced(new_Group);
                    new_Group = new_Group.substring(0, end);
                }
                else if (!rest.isEmpty() && rest.trim().charAt(0) == '(') {
                    end = find_brackets_balanced(rest);
                    new_Group += rest.substring(0, end);
                    end = new_Group.length();
                }

                if(end < text.length()) {
                    text = text.substring(end).trim(); //todo: this is old dont delete*******
                }
                else{
//                    System.out.println(
//                            "errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr");
                    text="";
                }
            }
            Element e = add_all_helper(term_tokinizer(new_Group), "term");
            elements.add(e);
            //find if expression has op afterwards
//            text = text.substring(end).trim(); //todo: this is old dont delete********
            //take apart rest of text
            m = Patterns.opPattern.matcher(text);
            if (m.find()) {
                if (text.length() > 0 && m.group(1) != null) {
                    //add operator (m.group(1))
                    elements.add(make_element(DOC, "symbol", m.group(1).trim()));

                    text = m.group(3).trim();
                    //take apart right term (recursive call to this function)
                    elements.addAll(expression(text));
                } else {
                    if (text.length() != 0) {
                        System.out.println("ERROR 404 - Page Not el~fucke " + System.lineSeparator());
                    }
                }
            }
        }

        return elements;
    }

//    public static ArrayList<Element> expression_list(String text) { //todo: can be a loop
//
//        ArrayList<Element> elements = new ArrayList<>();
//        String last_exp = "";
//        if(text.contains("(subX-(subWidth/2)")){
//            System.out.print("");
//        }
//        while (!text.equals("")) {
//            Matcher m = Patterns.expression_first_Pattern.matcher(text);
//            if (m.find()) {
//                //add first part of expression m.group(1)
//                last_exp += m.group(1).trim();
//                //find if expression has op afterwards
//                int end = m.end(1);
//                text = text.substring(end).trim();
//                m = Patterns.opPattern.matcher(text);
//                if (m.find()) {
//                    if (text.length() > 0 && m.group(1) != null) {
//                        //add operator (m.group(1))
//                        last_exp += m.group(1).trim();
//                        text = m.group(3).trim();
//                        continue;
//                    }
//                }
//                else if (text.length() > 0 && text.charAt(0) == ',') {
//                    text = text.substring(1).trim(); //get rid of ,
//                    //send last_exp to expression
//                    Element e = add_all_helper(expression(last_exp), "expression");
//                    elements.add(e);
//                    elements.add(make_element(DOC, "symbol", ","));
//                    last_exp = "";
//                }
//                else {
//                    int newEnd = 0;
//                    if(text.length() > 0 && text.charAt(0) == '.'){
//                        newEnd = find_comma(text, 0);
//                        last_exp += text.substring(0,newEnd);
//                        if(newEnd < text.length()){
//                            text = text.substring(newEnd+1);
//                        }
//                        else {
//                            text="";
//                        }
//
//                    }
//                    //send last_exp to expression
//                    Element e = add_all_helper(expression(last_exp), "expression");
//                    elements.add(e);
//                    if(!text.trim().isEmpty()){
//                        elements.add(make_element(DOC, "symbol", ","));
//                    }
//                    last_exp = "";
//                }
//
//            } else {
//                System.out.println("shouldve reached end but we didnt.");
//            }
//        }
//        return elements;
//    }


    public static ArrayList<Element> expression_list(String text) { //todo: can be a loop

        ArrayList<Element> elements = new ArrayList<>();
        String last_exp = "";
        if(text.contains("RushHour.")){
            System.out.print("");
        }
        while (!text.trim().equals("")) {
            int newEnd = 0;
            if(text.length() > 0){
                newEnd = find_comma(text, 0);
                last_exp += text.substring(0,newEnd).trim();
                if(newEnd < text.length()){
                    text = text.substring(newEnd+1).trim();
                }
                else {
                    text="";
                }

            }
            if(!last_exp.isEmpty()) {
                //send last_exp to expression
                Element e = add_all_helper(expression(last_exp), "expression");
                elements.add(e);
                if (!text.trim().isEmpty()) {
                    elements.add(make_element(DOC, "symbol", ","));
                }
            }
            last_exp = "";
        }


        return elements;
    }
}