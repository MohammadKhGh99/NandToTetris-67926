import java.io.File;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * a class that takes a File in the constructor, if the file exists, and is not a directory, process its lines
 * (type was previously checked by the main class), delete empty lines, white spaces, and comments
 */
public class Lines {
    private Translations VM_DATABASE = Translations.getTranslations();
    public ArrayList<String> lines = new ArrayList<>();
    public ArrayList<String> output = new ArrayList<>();
    private String fileName;


    //    private String labelRegex = "^\\((.+)\\)$"; //todo: global var
//    private String varRegex = "^@(.+)$"; //todo: check what is a legal symbol syntax
    private String numRegex = "\\d+";
    private Pattern num = Pattern.compile(numRegex);


    public Lines(File file) throws Exception {
        if (file.exists() && !file.isDirectory()) {
            this.lines = readLines(file);
            fileName = file.getName();
            parse_all();
        }
    }

    /**
     * @param file a file of type .vm add its lines to the arraylist called lines,
     *             no empty lines, no spaces or comments.
     * @return the array list object containing the lines
     */
    static private ArrayList<String> readLines(File file) throws IOException {
        BufferedReader reader;
        ArrayList<String> lines = new ArrayList<>();
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            while (line != null) {
                line = line.replaceAll("//.*$", ""); //delete comments
                line = line.replaceAll("\\s+", " "); //replace all white spaces with a single white space
                line = line.trim(); //delete leading and trailing white spaces
                if (!line.isEmpty()) {
                    lines.add(line);
                }
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
        return lines;
    }

    public String parse_line(String line) throws Exception {
        String[] parts = line.split(" ");
        if (parts.length == 3) {
            //push/pop operation
            // check validity of index 1 and 2
            if (!(num.matcher(parts[2]).matches())) {
                throw new Exception("invalid line: " + line);
            }
            //check push //todo: add function and whatever is needed (else if)
            if (parts[0].equals("push")) {
                return VM_DATABASE.get_push(fileName, parts[1], parts[2]);
            }
            //check pop
            else if (parts[0].equals("pop")) {
                return VM_DATABASE.get_pop(fileName, parts[1], parts[2]);
            } else {
                throw new Exception(parts[0] + "not supported");
            }
        } else if (parts.length == 1) {
            //arithmetic operation
            return VM_DATABASE.get_Arithmetic(parts[0]);
        } else {

            throw new Exception("wrong command");

        }
    }

    private void parse_all() throws Exception {
        try {
            for (String line : lines) {
                output.add(parse_line(line));
            }
        } catch (Exception e) {
            throw e;
        }
//        finally {
//            VM_DATABASE.reset_counter();
//        }
    }
//
//    public static void main(String[] args) throws IOException {
//        File f = new File( "C:\\Users\\basel\\Desktop\\nand2tetris\\projects\\07\\java\\StaticTest.vm" );
//        ArrayList<String>  l = Lines.readLines(f);
//        System.out.println( );
//    }
}
