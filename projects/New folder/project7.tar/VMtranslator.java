import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;

public class VMtranslator
{
    private final static String TYPE = "vm";
    private static ArrayList<String> output_asm = new ArrayList<>();

    public static void main(String[] args)throws Exception
    {
        String path = "";
        if(args.length == 1){
            path = args[0];
        }
        else if(args.length > 1 ){
            throw new Exception();
        }
        File pathInput = new File(path).getCanonicalFile();
        if(pathInput.isDirectory()){
            int last = pathInput.getCanonicalPath().lastIndexOf(File.separatorChar);
            if (last == -1){
                return;
            }
            listAllFiles(pathInput);

            String path_ = pathInput.getCanonicalPath().substring(last+1);
            write_to_file(pathInput.getCanonicalPath() +File.separatorChar+path_, output_asm);
        }
        else if(pathInput.exists()) {
            int last = pathInput.getCanonicalPath().lastIndexOf(".vm");
            if (last == -1){
                return;
            }
            fileProcess(pathInput, last);
//            String type = pathInput.getCanonicalPath().substring(last+1);
            String path_ = pathInput.getCanonicalPath().substring(0,last);
            write_to_file(path_ ,output_asm);
        }
        else{
            return;
        }

    }

    public static void listAllFiles(File folder) throws IOException {
        File[] fileNames = folder.listFiles();
        assert fileNames != null;
        for (File file : fileNames) {
            int last = file.getCanonicalPath().lastIndexOf(".vm");
            if (last == -1){
                continue;
            }
            fileProcess(file,last);
        }
    }

    public static void fileProcess(File file, int last) throws IOException {
        String type = file.getCanonicalPath().substring(last+1);
        if(TYPE.equals(type)){
            try {
                Lines l = new Lines(file);
                output_asm.addAll(l.output); // we get here if the last line executed as needed
//                FileWriter writer = new FileWriter(path + ".asm");
//                for(String str: l.output) {
//                    writer.write(str + System.lineSeparator());
//                }
//                writer.close();
            }catch (Exception e){
                //don't do anything ..
                System.out.println(e.getMessage()); //todo: delete
            }
        }
    }

    public static void write_to_file(String path_and_name, ArrayList<String> lines) throws IOException {
        FileWriter writer = new FileWriter(path_and_name + ".asm");
        for(String str: lines) {
            writer.write(str + System.lineSeparator());
        }
        writer.close();
    }

}
