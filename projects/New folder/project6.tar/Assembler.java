import java.io.*;
import java.nio.file.Paths;

public class Assembler
{
    private final static String TYPE = "asm";

    public static void main(String[] args)throws Exception
    {
        String path = "";
        if(args.length == 1){
            path = args[0];
        }
        else if(args.length > 1 ){
            throw new Exception();
        }
        File pathInput = new File(path).getCanonicalFile();
        if(pathInput.isDirectory()){
            listAllFiles(pathInput);
        }
        else if(pathInput.exists()) {
            fileProcess(pathInput);
        }

    }

    public static void listAllFiles(File folder) throws IOException {
        File[] fileNames = folder.listFiles();
        assert fileNames != null;
        for (File file : fileNames) {
            fileProcess(file);
        }
    }

    public static void fileProcess(File file) throws IOException {
        int last = file.getCanonicalPath().lastIndexOf(".asm");
        if (last == -1){
            return;
        }
        String type = file.getCanonicalPath().substring(last+1);
        String path = file.getCanonicalPath().substring(0,last);
        if(TYPE.equals(type)){
            try {
                Lines l = new Lines(file);
                FileWriter writer = new FileWriter(path + ".hack");
                for(String str: l.output) {
                    writer.write(str + System.lineSeparator());
                }
                writer.close();
            }catch (Exception e){
                //don't do anything ..
//                System.out.println(e.getMessage()); //todo: delete
            }
        }
    }

}
