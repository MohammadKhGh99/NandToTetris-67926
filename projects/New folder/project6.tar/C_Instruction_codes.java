import java.util.HashMap;

//todo: 111 + comp + dest + jump
public class C_Instruction_codes {
    private static HashMap<String, String> comp = new HashMap<>(  );
    private static HashMap<String, String> dest = new HashMap<>(  );
    private static HashMap<String, String> jump = new HashMap<>(  );
    private static C_Instruction_codes inst =  new C_Instruction_codes();

    public String getComp(String cmp) throws Exception {
        if (comp.containsKey( cmp )) {
            return comp.get( cmp );
        }
        throw new Exception("illegal c instruction comp (" + cmp + ")");
    }

    public String getDest(String dst) throws Exception {
        if(dest.containsKey( dst )){
            return dest.get( dst );
        }
        throw new Exception("illegal c instruction dest (" + dst + ")");
    }

    public String getJump(String jmp) throws Exception {
        if(jump.containsKey( jmp )) {
            return jump.get( jmp );
        }
        throw new Exception("illegal c instruction jump (" + jmp + ")");
    }

    private C_Instruction_codes(){
        init_comp();
        init_dest();
        init_jmp();
    }

    public static C_Instruction_codes get(){
//        if(inst == null){
//            inst = new C_Instruction_codes();
//        }
        return inst;
    }


    //a c1 c2 c3 c4 c5 c6
    private static void init_comp(){
        String intro = "111";
        String intro_shift = "101";
        comp.put("0", intro +  "0101010");
        comp.put("1", intro +  "0111111");
        comp.put("-1", intro + "0111010");
        comp.put("D", intro +  "0001100");
        comp.put("A", intro +  "0110000");
        comp.put("M", intro +  "1110000");
        comp.put("!D", intro + "0001101");
        comp.put("!A", intro + "0110001");
        comp.put("!M", intro + "1110001");
        comp.put("-D", intro + "0001111");
        comp.put("-A", intro + "0110011");
        comp.put("-M", intro + "1110011");
        comp.put("D+1", intro +"0011111");
        comp.put("A+1", intro +"0110111");
        comp.put("M+1", intro +"1110111");
        comp.put("D-1", intro +"0001110");
        comp.put("A-1", intro +"0110010");
        comp.put("M-1", intro +"1110010");
        comp.put("D+A", intro +"0000010");
        comp.put("D+M", intro +"1000010");
        comp.put("D-A", intro +"0010011");
        comp.put("D-M", intro +"1010011");
        comp.put("A-D", intro +"0000111");
        comp.put("M-D", intro +"1000111");
        comp.put("D&A", intro +"0000000");
        comp.put("D&M", intro +"1000000");
        comp.put("D|A", intro +"0010101");
        comp.put("D|M", intro +"1010101");
        comp.put("D<<", intro_shift + "0110000");
        comp.put("A<<", intro_shift + "0100000");
        comp.put("M<<", intro_shift + "1100000");
        comp.put("D>>", intro_shift + "0010000");
        comp.put("A>>", intro_shift + "0000000");
        comp.put("M>>", intro_shift + "1000000");
    }

    private static void init_dest() {
        dest.put(null, "000");
        dest.put("M",  "001");
        dest.put("D",  "010");
        dest.put("MD", "011");
        dest.put("A",  "100");
        dest.put("AM", "101");
        dest.put("AD", "110");
        dest.put("AMD","111");
    }

    private static void init_jmp() {
        jump.put(null, "000");
        jump.put("JGT","001");
        jump.put("JEQ","010");
        jump.put("JGE","011");
        jump.put("JLT","100");
        jump.put("JNE","101");
        jump.put("JLE","110");
        jump.put("JMP","111");
    }


}
