
public class C_Instruction {
    private String code;

    C_Instruction(String line) throws Exception {
        parse(line);
    }

    void parse(String inst) throws Exception {
        int max_split = 2;
        String dest;
        String comp;
        String jmp;
        String[] destcomp = inst.split( "=" ,max_split);
        if(destcomp.length == 2){
            //dest exists, check the rest
            dest = destcomp[0];
            String[] compjmp = destcomp[1].split( ";" ,max_split);
            if(compjmp.length == 2){
                //dest comp and jump exist
                comp = compjmp[0];
                jmp = compjmp[1];
            }
            else if(compjmp.length == 1){
                //dest and comp exist
                jmp = null;
                comp = compjmp[0];
            }
            else {
                throw new Exception( "illegal syntax" );
            }

        }
        else if(destcomp.length == 1){
            //dest doesnt exist, check the rest
            //something(;something)?
            String[] compjmp = destcomp[0].split( ";" ,max_split);
            if(compjmp.length == 2){
                //comp and jump exist
                dest = null;
                comp = compjmp[0];
                jmp = compjmp[1];
            }
            else if(compjmp.length == 1){
                //comp exist
                comp = compjmp[0];
                dest = null;
                jmp = null;
            }
            else {
                throw new Exception( "illegal syntax" );
            }
        }
        else {
            throw new Exception( "illegal syntax" );
        }

        C_Instruction_codes codes = C_Instruction_codes.get();
        this.code = codes.getComp( comp ) + codes.getDest( dest ) +codes.getJump( jmp ) ;
    }

    public String getCode() {
        return code;
    }

}
