import java.util.regex.Pattern;

//todo: is KBD our max value or 32767?
public class A_Instruction {
    private String result;
    final static private Pattern A_Inst_Regex = Pattern.compile( "^@\\d+$" ); //todo: check what is a legal symbol syntax

    A_Instruction(String line){
        //get number as string in binary
        String n = toBinaryString(line.substring( 1 ));
        this.result = ("0000000000000000" + n).substring(n.length());
    }

    private String toBinaryString(String intStr){
        int num = Integer.parseInt( intStr );
        return Integer.toBinaryString(num );
    }

    public String getResult() {
        return result;
    }

    public static boolean Is_A_Instruction(String line){
        return A_Inst_Regex.matcher( line ).matches();
    }


}
