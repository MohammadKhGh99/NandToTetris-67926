import java.io.File;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * a class that takes a File in the constructor, if the file exists, and is not a directory, process its lines
 * (type was previously checked by the main class), delete empty lines, white spaces, and comments
 */
public class Lines {
    public ArrayList<String> lines = new ArrayList<>();
    public ArrayList<String> output = new ArrayList<>();
    private HashMap<String, Integer> symbolTable = new HashMap<>();

    private String labelRegex = "^\\((.+)\\)$"; //todo: global var
    private String varRegex = "^@(.+)$"; //todo: check what is a legal symbol syntax
    private String numRegex = "\\d+";




    public Lines(File file) throws Exception {
        if(file.exists() && !file.isDirectory()){
            this.lines = readLines(file);
            processLines();
        }
    }

    /**
     * a function that does it all
     */
    public void processLines() throws Exception {
        //add predefined
        add_predefined();
        //scan all the labels, remove them and add them to the table
        scanLabels();
        //replace variables in the code (A instruction)

        add_vars();
        //translate the lines and save to the class's output
        translate_lines(this.lines);
    }

    private void translate_lines(ArrayList<String> lines) throws Exception {
        int i = 1;
        for(String instruction: lines){
            try {
                if (A_Instruction.Is_A_Instruction(instruction)) {
                    A_Instruction res = new A_Instruction(instruction);
                    output.add(res.getResult());
                } else {
                    C_Instruction res = new C_Instruction(instruction);
                    output.add(res.getCode());

                }
            }
            catch(Exception e){
                throw new Exception(e.getMessage() + "-- line: "+i);
            }
            i++;
        }

    }
    private void add_predefined(){
        //adding R0..R15
        for(int i = 0; i<16;i++){
            symbolTable.put( "R"+i ,i);
        }
        symbolTable.put( "SCREEN" ,16384);
        symbolTable.put( "KBD" ,24576);
        symbolTable.put( "SP" ,0);
        symbolTable.put( "LCL" ,1);
        symbolTable.put( "ARG" ,2);
        symbolTable.put( "THIS" ,3);
        symbolTable.put( "THAT" ,4);
    }

    /**
     *
     * @param file a file of type .asm add its lines to the arraylist called lines,
     *             no empty lines, no spaces or comments.
     * @return the array list object containing the lines
     */
    static private ArrayList<String> readLines(File file) throws IOException {
        BufferedReader reader;
        ArrayList<String> lines = new ArrayList<>();
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            while (line != null) {
                line = line.replaceAll( "//.*$","" );
                line = line.replaceAll( "\\s+","" );
                if (!line.isEmpty()) {
                    lines.add(line);
                }
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
        return lines;
    }

    void scanLabels(){
        Iterator<String> it = lines.iterator();
        int i = 0;

        while(it.hasNext()){
            String line = it.next();
            Matcher m = Pattern.compile(labelRegex).matcher(line);
            if(m.matches()){
                String label = m.group( 1 );
                //if label isnt in the table
                if(!symbolTable.containsKey( label )){
                    symbolTable.put(label,i);
                    it.remove();
                }
            }
            //todo: check if legal type
            else{
                i++;
            }
        }
    }

    private void add_vars()throws Exception{
        Matcher m;
        Matcher num;

        int varIndex = 16;
        for(int i=0; i<this.lines.size(); i++){
            m = Pattern.compile(varRegex).matcher(this.lines.get( i ));
            if(m.matches()) {
                num = Pattern.compile( numRegex ).matcher( m.group( 1 ) );
                //if @[variable_name] is the name
                if (!num.matches( )) {
                    String varName = m.group( 1 );
                    if (!this.symbolTable.containsKey( varName )) {
                        //key doesnt exist
                        this.symbolTable.put( varName, varIndex );
                        varIndex++;
                    }
                    //replace the variable in the line
                    this.lines.set( i, "@" + this.symbolTable.get( varName ) );
                }
            }
        }
    }
}
